
from django.urls import path
from .views import home,PropertycreateView , PropertyUpdateView

urlpatterns = [
    path('',home,name='home'),
    path('create',PropertycreateView,name='create'),
    path('update/pk=<int:pk>',PropertyUpdateView,name='update'),
]
 