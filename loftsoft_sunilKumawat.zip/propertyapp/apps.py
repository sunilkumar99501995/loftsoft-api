from django.apps import AppConfig


class PropertyappConfig(AppConfig):
    name = 'propertyapp'
