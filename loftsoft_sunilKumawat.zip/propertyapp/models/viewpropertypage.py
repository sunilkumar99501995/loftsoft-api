from django.db import models
from django.contrib.auth.models import User
from django.http import request


class Property(models.Model):
    propertyName = models.CharField(max_length=40 , null=False)
    city = models.CharField(max_length=20 , null=False)
    is_public = models.BooleanField(default=False)
    user = models.ForeignKey(User , null=False,on_delete=models.CASCADE)

    def __str__(self):
        return self.user.username