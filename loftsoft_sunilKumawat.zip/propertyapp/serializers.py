from django.db import models
from django.db.models import fields
from rest_framework import serializers
from propertyapp.models import Property 
from django.contrib.auth.models import User
from django.db.models import fields

class PropertySerializers(serializers.ModelSerializer):
    class Meta:
        model = Property
        fields ='__all__'


            



    


    