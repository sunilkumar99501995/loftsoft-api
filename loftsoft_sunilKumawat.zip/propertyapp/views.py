from decimal import Context
from django.core.exceptions import ValidationError
from rest_framework import generics, serializers
from propertyapp.models.viewpropertypage import Property
from propertyapp.serializers import PropertySerializers
from django.shortcuts import redirect, render

import json
from django.http import JsonResponse
from django.http.response import HttpResponse

from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response




# class PropertycreateView(generics.ListCreateAPIView):
#     queryset = Property.objects.all()
#     serializer_class = PropertySerializers

def home(request):
    return render(request,template_name="propertyapp/home.html")


@api_view(['POST','GET'])
def PropertycreateView(request,pk=None):
    if request.user.is_authenticated:
        if request.method=='GET':
            if pk==None:
                propertyData = Property.objects.filter(is_public=True)
                seri = PropertySerializers(propertyData,many = True)
                print(seri)
                context ={
                    'datas':seri
                }
                return Response(seri.data)

            else:
                try:
                    propertyData = Property.objects.get(id=pk)
                    seri = PropertySerializers(propertyData)
                    return Response(seri.data)
                except Property.DoesNotExist:
                    return Response({"message":"record not found"})


    
        if request.method=='POST':
            try:
                propertyNameUser = Property.objects.filter(user_id=request.user.id).first()                
            except:
            
                propertyData = PropertySerializers(data = request.data)  # json data conversion into taxt

                if propertyData.is_valid():
                    # propertyData.user_id = request.user.id
                    propertyData.save()
                    return Response({'message':'successfull data Submitted'})
                else:
                    return Response({'message':'failed data Submitted'})
               
            
            return Response({"message":"Your Record ai allready exist or You Don't have permission"})

    else:
        return Response({'status':'Failed','message':'permission denied , Please Login'})


# @csrf_exempt

@api_view(['PUT'])
def PropertyUpdateView(request,pk):
    if request.user.is_authenticated:
        try:
            propertyData = Property.objects.filter(user_id=request.user.id).first()

                
        except Property.DoesNotExist:
            return Response({'Message':"Your Record Not Found"})
        if request.method=='PUT':
            empobj = PropertySerializers(propertyData ,data = request.data)
            
            if empobj.is_valid():
                
                empobj.save()
                return Response({'status':'Success','message':'Data is Successfully Updated'})
            else:
                return Response({'status':'Failed','message':'Invalid Data'})

        
    else:
        return Response({'status':'Failed','message':'permission denied , Please Login'})
    




    
