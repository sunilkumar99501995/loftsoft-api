from usercreateapp.forms.registration_forms import RegistrationForm
from usercreateapp.forms.login_forms import LoginForm
