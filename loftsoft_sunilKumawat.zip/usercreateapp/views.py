from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import logout

# Create your views here.
from django.views import View
from .forms import RegistrationForm , LoginForm


class createUser(View):
    def get(self,request):
        forms = RegistrationForm()
        context = {
            'forms':forms
        }
        return render(request,template_name ='usercreateapp/signup.html', context=context)

    def post(self,request):
        forms = RegistrationForm(request.POST)
        if forms.is_valid():
            forms.save()
            return redirect('home')
            return HttpResponse("you are logged user")
        else:
            return render(request,template_name='usercreateapp/signup.html',context={'forms':forms})




class LoginUser(View):
    def get(self,request):
        form =LoginForm()
        context = {'form':form}
        return render(request,template_name="usercreateapp/signin.html",context=context)

    def post(self,request):
        form = LoginForm(request=request,data = request.POST)
        context = {
            'form':form
        }
        if form.is_valid():
            # return HttpResponse("success login");
            return redirect('home')
        else:
            return render(request,"usercreateapp/signin.html",context=context)
        
def signout(request):
    logout(request)
    return redirect('/')