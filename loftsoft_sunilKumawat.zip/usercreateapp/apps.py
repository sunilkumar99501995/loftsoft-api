from django.apps import AppConfig


class UsercreateappConfig(AppConfig):
    name = 'usercreateapp'
